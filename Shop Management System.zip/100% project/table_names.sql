clear screen;



create table EMPLOYEE(
    first_name employees.first_name%TYPE,
    last_name employees.last_name%TYPE,
    phn_no employees.phn_no%TYPE,
    address employees.address%TYPE,
    age employees.age%TYPE
  );

create table EMPLOYEE_INFO(
    e_name VARCHAR(30),
    house_number2 VARCHAR2(6),
    street2       VARCHAR2(50),
    phone2        VARCHAR2(15),
    region2       VARCHAR2(10),
    postal_code2  VARCHAR2(10),
    country2      VARCHAR2(25),
    age2 NUMBER(2)
  );

create table EMPLOYEE_SAL(
    first_name employees.first_name%TYPE,
    last_name employees.last_name%TYPE,
    n_sal employees.sal%TYPE
  );



create table CUSTOMER(
    customer_name    c_name,
    c_address CUSTOMER.address%TYPE,
    value n_value
  );

create table CUSTOMER_INFO(
    customer_name VARCHAR(30),
    house_number VARCHAR2(6),
    street       VARCHAR2(50),
    phone        VARCHAR2(15),
    region       VARCHAR2(10),
    postal_code  VARCHAR2(10),
    country      VARCHAR2(25),
    age NUMBER(2)
  );



create table CUSTOMER_PRODUCT(
    name VARCHAR2(6),
    quality      VARCHAR2(50),
    date        VARCHAR2(15),
    
  );

create table MANAGER(
    name VARCHAR2(6),
    m_address      VARCHAR2(50),
    m_phn_no        VARCHAR2(15),
    
  );


create table Manager_INFO(
    A_name VARCHAR2(30),
    house_number3 VARCHAR2(6),
    street3       VARCHAR2(50),
    phone3        VARCHAR2(15),
    region3       VARCHAR2(10),
    postal_code3  VARCHAR2(10),
    country3      VARCHAR2(25),
    age3 NUMBER(2)
  );

