CREATE OR REPLACE PROCEDURE product2(
    
  product_name IN NUMBER,
  quality IN VARCHAR2(6),
  exp_date  IN  VARCHAR2(10) 
    
) IS
BEGIN

SELECT product_name,
         quality
  INTO name,
       quality
  FROM CUSTOMER_PRODUCT
  WHERE name = (SELECT name
                 FROM CUSTOMER_PRODUCT
                 WHERE name = product_name);
 

   
  SELECT exp_date
  INTO date
  FROM CUSTOMER_PRODUCT
  WHERE date =exp_date;


 
 

END;
/
