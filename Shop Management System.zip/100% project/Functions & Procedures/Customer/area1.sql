CREATE OR REPLACE PROCEDURE area1(
    c_name VARCHAR2(30),
    house_number VARCHAR2(6),
    street       VARCHAR2(50),
    phone        VARCHAR2(15),
    region       VARCHAR2(10),
    postal_code  VARCHAR2(10),
    country      VARCHAR2(25),
    age NUMBER(2)
    
) IS
BEGIN

SELECT c_name,house_number,street,phone,
    region ,
    postal_code,
    country,
    age
         
  INTO customer_name,house_number,street,phone,
    region ,
    postal_code,
    country,
    age
         
  FROM CUSTOMER_INFO
  WHERE house_number = (SELECT c_address
                 FROM CUSTOMER
                 WHERE c_address = house_number);
 

   
  SELECT region
  INTO region
  FROM CUSTOMER_INFO
  WHERE region =region;

  
  SELECT postal_code
  INTO postal_code
  FROM CUSTOMER_INFO
  WHERE postal_code=postal_code;


  SELECT country
  INTO country
  FROM CUSTOMER_INFO
  WHERE country=country;

SELECT age
  INTO age
  FROM CUSTOMER_INFO
  WHERE age=age;

 
 

END;
/
