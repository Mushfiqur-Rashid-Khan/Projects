CREATE OR REPLACE PROCEDURE value3(
    n_min_value NUMBER,
  n_max_value IN NUMBER,
  n_mid_value IN NUMBER,
  n_value  IN   CUSTOMER.VALUE%TYPE
    
) IS
BEGIN

SELECT min_value,
         max_value
  INTO n_min_value,
       n_max_value
  FROM CUSTOMER
  WHERE name = (SELECT name
                 FROM CUSTOMER_PRODUCT
                 WHERE name = proiduct_name);
 

   n_mid_value := (n_min_value + n_max_value) / 2;
  -- get salary of the given employee
  SELECT value
  INTO n_value
  FROM CUSTOMER
  WHERE c_name = customer_name;
