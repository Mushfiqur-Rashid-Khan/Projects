SET SERVEROUTPUT ON SIZE 1000000;
DECLARE
  
  n_emp_id EMPLOYEES.EMPLOYEE_ID%TYPE := 200;
  

CREATE OR REPLACE PROCEDURE check_salary(
    n_salary EMPLOYEES.SALARY%TYPE,
    v_msg    VARCHAR
) IS

BEGIN
  SELECT salary
  INTO n_salary
  FROM employees
  WHERE employee_id = n_emp_id;
 
  CASE
    WHEN n_salary < 2000 THEN
      v_msg := 'Low';
    WHEN n_salary >= 2000 and n_salary <=3000 THEN
      v_msg := 'Fair';
    WHEN n_salary >= 3000 THEN
      v_msg := 'High';
  END CASE;
  DBMS_OUTPUT.PUT_LINE(v_msg);
END;
/