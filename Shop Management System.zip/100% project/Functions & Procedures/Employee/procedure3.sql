 
CREATE OR REPLACE PROCEDURE calculate mid-range(
    n_min_salary NUMBER,
  n_max_salary IN NUMBER,
  n_mid_salary IN NUMBER,
  n_salary  IN   EMPLOYEES.SALARY%TYPE
    
) IS
BEGIN

SELECT min_salary,
         max_salary
  INTO n_min_salary,
       n_max_salary
  FROM JOBS
  WHERE JOB_ID = (SELECT JOB_ID
                 FROM EMPLOYEES
                 WHERE EMPLOYEE_ID = n_emp_id);
 

   n_mid_salary := (n_min_salary + n_max_salary) / 2;
  -- get salary of the given employee
  SELECT salary
  INTO n_salary
  FROM employees
  WHERE employee_id = n_emp_id;


 
 

END;
/





  