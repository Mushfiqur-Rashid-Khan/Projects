SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE comp_salary(
n_min_salary NUMBER,
  n_max_salary IN NUMBER,
  n_mid_salary IN NUMBER,
  n_salary  IN   EMPLOYEES.SALARY%TYPE
    
) IS
BEGIN
   IF n_salary < n_mid_salary THEN
    UPDATE employees
    SET salary = n_mid_salary
    WHERE employee_id = n_emp_id;
  END IF;


-- update employee's salary if it is lower than
  -- the mid range, otherwise increase 5%
  IF n_salary > n_mid_salary THEN
    DBMS_OUTPUT.PUT_LINE('Employee ' || TO_CHAR(n_emp_id) ||
                         ' has salary $' || TO_CHAR(n_salary) ||
                         ' higher than mid-range $' || TO_CHAR(n_mid_salary));
  ELSIF n_salary < n_mid_salary THEN
    DBMS_OUTPUT.PUT_LINE('Employee ' || TO_CHAR(n_emp_id) ||
                         ' has salary $' || TO_CHAR(n_salary) ||
                         ' lower than mid-range $' || TO_CHAR(n_mid_salary));
 
  ELSE
    DBMS_OUTPUT.PUT_LINE('Employee ' || TO_CHAR(n_emp_id) ||
                         ' has salary $' || TO_CHAR(n_salary) ||
                         ' equal to mid-range $' || TO_CHAR(n_mid_salary));
  END IF;

END;
/