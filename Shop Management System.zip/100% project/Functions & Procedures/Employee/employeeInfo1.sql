CREATE OR REPLACE PROCEDURE area1(
    e_name VARCHAR2(30),
    house_number2 VARCHAR2(6),
    street2       VARCHAR2(50),
    phone2        VARCHAR2(15),
    region2       VARCHAR2(10),
    postal_code2  VARCHAR2(10),
    country2      VARCHAR2(25),
    age2 NUMBER(2)
    
) IS
BEGIN

SELECT e_name,house_number2,street2,phone2,
    region2 ,
    postal_code2,
    country2,
    age2
         
  INTO e_name,house_number2,street2,phone2,
    region2 ,
    postal_code2,
    country2,
    age2
         
  FROM EMPLOYEE_INFO
  WHERE house_number2 = (SELECT address
                 FROM EMPLOYEE
                 WHERE address = house_number2);
 

   
  SELECT region2
  INTO region2
  FROM EMPLOYEE_INFO
  WHERE region2 =region2;

  
  SELECT postal_code2
  INTO postal_code2
  FROM EMPLOYEE_INFO
  WHERE postal_code2=postal_code2;


  SELECT country2
  INTO country2
  FROM EMPLOYEE_INFO
  WHERE country2=country2;

SELECT age2
  INTO age2
  FROM EMPLOYEE_INFO
  WHERE age2=age2;

 
 

END;
/
