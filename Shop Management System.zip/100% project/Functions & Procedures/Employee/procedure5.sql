SET SERVEROUTPUT ON SIZE 1000000;
DECLARE
  
  n_emp_id employees.employee_id%TYPE := 145;

CREATE OR REPLACE PROCEDURE get_commission_percentage(
    n_pct    employees.commission_pct%TYPE,
  v_eval   varchar2
) IS

BEGIN
  
  SELECT commission_pct
  INTO n_pct
  FROM employees
  WHERE employee_id = n_emp_id;
 
  -- evalutate commission percentage
  CASE n_pct
    WHEN 0 THEN
      v_eval := 'N/A';
    WHEN 0.1 THEN
      v_eval := 'Low';
    WHEN 0.2 THEN
      v_eval := 'High';
    ELSE
      v_eval := 'Fair';
  END CASE;
  -- print commission evaluation
  DBMS_OUTPUT.PUT_LINE('Employee ' || n_emp_id || 
                       ' commission ' || TO_CHAR(n_pct) ||
                       ' which is '   || v_eval);
END;
/




