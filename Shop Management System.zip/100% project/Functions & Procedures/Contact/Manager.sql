CREATE OR REPLACE PROCEDURE Manager_area(
    A_name VARCHAR2(30),
    house_number3 VARCHAR2(6),
    street3       VARCHAR2(50),
    phone3        VARCHAR2(15),
    region3       VARCHAR2(10),
    postal_code3  VARCHAR2(10),
    country3      VARCHAR2(25),
    age3 NUMBER(2)
    
) IS
BEGIN

SELECT A_name,house_number3,street3,phone3,
    region3,
    postal_code3,
    country3,
    age3
         
  INTO A_name,house_number3,street3,phone3,
    region3 ,
    postal_code3,
    country3,
    age3
         
  FROM EMPLOYEE_INFO
  WHERE house_number3 = (SELECT m_address
                 FROM MANAGER
                 WHERE m_address = house_number3);
 

   
  SELECT region3
  INTO region3
  FROM MANAGER_INFO
  WHERE region3 =region3;

  
  SELECT postal_code3
  INTO postal_code3
  FROM MANAGER_INFO
  WHERE postal_code3=postal_code3;


  SELECT country3
  INTO country3
  FROM MANAGER_INFO
  WHERE country2=country3;

SELECT age3
  INTO age3
  FROM MANAGER_INFO
  WHERE age2=age3;

 
 

END;
/
