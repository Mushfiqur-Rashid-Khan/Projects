clear screen;

SET serveroutput ON SIZE 1000000;
DECLARE
  TYPE t_name IS RECORD(
    first_name employees.first_name%TYPE,
    last_name employees.last_name%TYPE
  );
  r_name      t_name;
  r_name2     t_name;
  r_name_null t_name;
  n_emp_id employees.employee_id%TYPE := 200;
BEGIN
  -- assign employee's infomation to record
  SELECT first_name,
         last_name
  INTO r_name
  FROM employees
  WHERE employee_id = n_emp_id;
 
  -- assign record to another record
  r_name2 := r_name;
  -- print out the employee's name
  DBMS_OUTPUT.PUT_LINE(r_name2.first_name || ',' || r_name2.last_name);
 
  -- assign record to NULL
  r_name2 := r_name_null; 
 
  -- check NULL for each individual field
  IF r_name2.first_name IS NULL AND
     r_name2.last_name IS NULL THEN
    DBMS_OUTPUT.PUT_LINE('Record r_name2 is NULL');
  END IF;
 
END;
/


DECLARE
  TYPE t_address IS RECORD(
    house_number VARCHAR2(6),
    street       VARCHAR2(50),
    phone        VARCHAR2(15),
    region       VARCHAR2(10),
    postal_code  VARCHAR2(10),
    country      VARCHAR2(25)
  );


 
  TYPE t_contact IS RECORD(
    home     t_address,
    business t_address
  );
  r_contact t_contact;
BEGIN
  r_contact.business.house_number := '14';
  r_contact.business.street       := 'Bonogram Lane,Wari';
  r_contact.business.region       := 'Dhaka';
  r_contact.business.postal_code  := '1203';
  r_contact.business.country      := 'Bangladesh';
  r_contact.business.phone        := '+01828036281';
END;
/