/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.awt.Color;
import javax.swing.JOptionPane;
import java.io.DataInputStream;  
import java.io.DataOutputStream;  
import java.net.Socket;
/**
 *
 * @author HP
 */
public class TicTakToe_s2 extends javax.swing.JFrame {
    
     static Socket sckt;  
    static DataInputStream dtinpt;  
    static DataOutputStream dtotpt; 
    
    
    

    private String startGame2="O";
    private int xCount2=0;
    private int oCount2=0;
    
   public void fillup(){
         this.setVisible(false);
        new Winner_Form().setVisible(true);
        
    }
    
    public void history(){
         this.setVisible(false);
        new History().setVisible(true);
        
    }
    
   
    
    public void mltd(){
        
        try  
    {  
        String msgout = " ";  
        msgout = jB1.getText().trim();  
        dtotpt.writeUTF(msgout);  
    }  
    catch (Exception e)  
    {  
    }  
        
        
    }
    
    
     public void fillup2(){
         this.setVisible(false);
        new Winner2_Form().setVisible(true);
        
    }
    
    private void gameScore2(){
        jlblPlayerX2.setText(String.valueOf(xCount2));
        jlblPlayerO2.setText(String.valueOf(oCount2));
        
        
    }
    
     private void choose_a_player1(){
      
       if(startGame2.equalsIgnoreCase("X")){
            startGame2="O";
        }
        else{
             startGame2="X";
        }
  
    }
    
    
    
    private void winningGame2(){
        
        String b1=jB1.getText();
        String b2=jB2.getText();
        String b3=jB3.getText();
        
        String b4=jB4.getText();
        String b5=jB5.getText();
        String b6=jB6.getText();
        
        String b7=jB7.getText();
        String b8=jB8.getText();
        String b9=jB9.getText();
        
        if(b1==("X") && b2==("X") && b3==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
        
            jB1.setBackground(Color.yellow);
            jB2.setBackground(Color.yellow);
            jB3.setBackground(Color.yellow);
            
        }
        
         if(b4==("X") && b5==("X") && b6==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB4.setBackground(Color.CYAN);
            jB5.setBackground(Color.CYAN);
            jB6.setBackground(Color.CYAN);
         
        }
        
         if(b7==("X") && b8==("X") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB7.setBackground(Color.CYAN);
            jB8.setBackground(Color.CYAN);
            jB9.setBackground(Color.CYAN);
            
        
        }
        
         if(b1==("X") && b4==("X") && b7==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB1.setBackground(Color.CYAN);
            jB4.setBackground(Color.CYAN);
            jB7.setBackground(Color.CYAN);
      
        }
         
         if(b2==("X") && b5==("X") && b8==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB2.setBackground(Color.CYAN);
            jB5.setBackground(Color.CYAN);
            jB8.setBackground(Color.CYAN);
       
        }
          
         if(b3==("X") && b6==("X") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB3.setBackground(Color.CYAN);
            jB6.setBackground(Color.CYAN);
            jB9.setBackground(Color.CYAN);
       
        }
           
         if(b1==("X") && b5==("X") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB1.setBackground(Color.CYAN);
            jB5.setBackground(Color.CYAN);
            jB9.setBackground(Color.CYAN);
            
         
        }
            
         if(b3==("X") && b5==("X") && b7==("X") ){
            JOptionPane.showMessageDialog(this, "Player X wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            xCount2++;
            gameScore2();
            
            jB3.setBackground(Color.CYAN);
            jB5.setBackground(Color.CYAN);
            jB7.setBackground(Color.CYAN);
        
        }
         
         if(b1==("O") && b2==("O") && b3==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
             fillup2();
          
        }
        
         if(b4==("O") && b5==("O") && b6==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
        
        }
        
       if(b7==("O") && b8==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
           
        }
        
         if(b1==("O") && b4==("O") && b7==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
           
        }
         
        if(b2==("O") && b5==("O") && b8==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
           
        }
          
        if(b3==("O") && b6==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
         
        }
           
         if(b1==("O") && b5==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
      
        }
            
         if(b3==("O") && b5==("O") && b7==("O") ){
            JOptionPane.showMessageDialog(this, "Player O wins","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            oCount2++;
            gameScore2();
            fillup2();
       
        }
        if(b1==("X") && b2==("O") && b3==("X") && b4==("O") && b5==("X") && b6==("O") && b7==("O") && b8==("X") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
        }
        
        if(b1==("O") && b2==("X") && b3==("O") && b4==("X") && b5==("O") && b6==("X") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
          
            
        }
        
        if(b1==("X") && b2==("O") && b3==("X") && b4==("O") && b5==("X") && b6==("X") && b7==("O") && b8==("X") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
        }
        
        if(b1==("X") && b2==("O") && b3==("X") && b4==("X") && b5==("X") && b6==("O") && b7==("O") && b8==("X") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
         
        }
        
         if(b1==("O") && b2==("X") && b3==("X") && b4==("X") && b5==("O") && b6==("O") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
         
        }
         
         if(b1==("O") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("O") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
         
        }
         
         if(b1==("X") && b2==("O") && b3==("X") && b4==("X") && b5==("O") && b6==("X") && b7==("O") && b8==("X") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
         
        }
         
          if(b1==("O") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("O") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
         
        }
          
          if(b1==("O") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("X") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
         
        }
          if(b1==("O") && b2==("X") && b3==("O") && b4==("X") && b5==("X") && b6==("O") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
        }
          
          if(b1==("O") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("X") && b7==("X") && b8==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
        }
          
          
          if(b1==("O") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("X") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
         
        }
          
          if(b1==("X") && b2==("X") && b3==("O") && b4==("O") && b5==("X") && b6==("X") && b7==("X") && b8==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
        }
          
           if(b1==("X") && b2==("X") && b3==("O") && b4==("O") && b5==("O") && b6==("X") && b7==("X") && b8==("O") && b9==("O") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
           
         
        }
           
           if(b1==("X") && b2==("X") && b3==("O") && b4==("O") && b5==("O") && b6==("X") && b7==("X") && b8==("O") && b9==("X") ){
            JOptionPane.showMessageDialog(this, "Match Drawn","Tic Tac Toe", JOptionPane.INFORMATION_MESSAGE);
            
            history();
            
        }
 
    }
   
    public TicTakToe_s2() {
        initComponents();
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jB1 = new javax.swing.JButton();
        jB2 = new javax.swing.JButton();
        jB3 = new javax.swing.JButton();
        jB4 = new javax.swing.JButton();
        jB5 = new javax.swing.JButton();
        jB6 = new javax.swing.JButton();
        jB7 = new javax.swing.JButton();
        jB8 = new javax.swing.JButton();
        jB9 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jlblPlayerX2 = new javax.swing.JLabel();
        jlblPlayerO2 = new javax.swing.JLabel();
        jbtnReset2 = new javax.swing.JButton();
        jbtnExit2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 70)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 0));
        jLabel1.setText("Tic Tac Toe");

        jB1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB1ActionPerformed(evt);
            }
        });

        jB2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB2ActionPerformed(evt);
            }
        });

        jB3.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB3ActionPerformed(evt);
            }
        });

        jB4.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB4ActionPerformed(evt);
            }
        });

        jB5.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB5ActionPerformed(evt);
            }
        });

        jB6.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB6ActionPerformed(evt);
            }
        });

        jB7.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB7ActionPerformed(evt);
            }
        });

        jB8.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB8ActionPerformed(evt);
            }
        });

        jB9.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jB9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB9ActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(102, 102, 0));
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        jLabel2.setText("Player X");

        jLabel3.setBackground(new java.awt.Color(255, 51, 153));
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        jLabel3.setText("Player O");

        jlblPlayerX2.setBackground(new java.awt.Color(255, 0, 0));

        jlblPlayerO2.setBackground(new java.awt.Color(102, 0, 0));

        jbtnReset2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jbtnReset2.setText("Reset");
        jbtnReset2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnReset2ActionPerformed(evt);
            }
        });

        jbtnExit2.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jbtnExit2.setText("Exit");
        jbtnExit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnExit2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(246, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB1, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                    .addComponent(jB4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB2, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                    .addComponent(jB5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB6, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                    .addComponent(jB3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbtnReset2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblPlayerX2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jlblPlayerO2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbtnExit2, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB2, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jlblPlayerX2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2)
                    .addComponent(jB1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jB5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jB6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblPlayerO2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jB4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jbtnReset2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jB7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jB8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jB9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbtnExit2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(211, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnReset2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnReset2ActionPerformed
        jB1.setText(null);
        jB2.setText(null);
        jB3.setText(null);
        
        jB4.setText(null);
        jB5.setText(null);
        jB6.setText(null);
        
        jB7.setText(null);
        jB8.setText(null);
        jB9.setText(null);
        
        
        jB1.setBackground(Color.LIGHT_GRAY);
        jB2.setBackground(Color.LIGHT_GRAY);
        jB3.setBackground(Color.LIGHT_GRAY);
        jB4.setBackground(Color.LIGHT_GRAY);
        jB5.setBackground(Color.LIGHT_GRAY);
        jB6.setBackground(Color.LIGHT_GRAY);
        jB7.setBackground(Color.LIGHT_GRAY);
        jB8.setBackground(Color.LIGHT_GRAY);
        jB9.setBackground(Color.LIGHT_GRAY);
        
    }//GEN-LAST:event_jbtnReset2ActionPerformed

    
    private void jbtnExit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnExit2ActionPerformed
    
        System.exit(0);

    }//GEN-LAST:event_jbtnExit2ActionPerformed

    private void jB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB1ActionPerformed
        
        mltd();
        
        jB1.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB1.setForeground(Color.GREEN);
           
        }
        else{
            
            jB1.setForeground(Color.BLUE);
            
        }
        
        
        choose_a_player1();
       
       winningGame2();
                 
    }//GEN-LAST:event_jB1ActionPerformed

    private void jB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB2ActionPerformed
        jB2.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB2.setForeground(Color.GREEN);
            
        }
        else{
            
            jB2.setForeground(Color.BLUE);
            
        }
        
        choose_a_player1();
       
       winningGame2();
    }//GEN-LAST:event_jB2ActionPerformed

    private void jB3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB3ActionPerformed
        jB3.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB3.setForeground(Color.GREEN);
            
        }
        else{
            
            jB3.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
       
       winningGame2();
    }//GEN-LAST:event_jB3ActionPerformed

    private void jB4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB4ActionPerformed
        jB4.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB4.setForeground(Color.GREEN);
            
        }
        else{
            
            jB4.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
       
       winningGame2();
    }//GEN-LAST:event_jB4ActionPerformed

    private void jB5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB5ActionPerformed
        jB5.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB5.setForeground(Color.GREEN);
            
        }
        else{
            
            jB5.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
       
       winningGame2();
    }//GEN-LAST:event_jB5ActionPerformed

    private void jB6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB6ActionPerformed
       jB6.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB6.setForeground(Color.GREEN);
            
        }
        else{
            
            jB6.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
     
       winningGame2();
    }//GEN-LAST:event_jB6ActionPerformed

    private void jB7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB7ActionPerformed
       jB7.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB7.setForeground(Color.GREEN);
            
        }
        else{
            
            jB7.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
      
       winningGame2();
    }//GEN-LAST:event_jB7ActionPerformed

    private void jB8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB8ActionPerformed
      jB8.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB8.setForeground(Color.GREEN);
            
        }
        else{
            
            jB8.setForeground(Color.BLUE);
            
        }
        choose_a_player1();
      
       winningGame2();
    }//GEN-LAST:event_jB8ActionPerformed

    private void jB9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB9ActionPerformed
        jB9.setText(startGame2);
        
      
        if(startGame2.equalsIgnoreCase("X")){
            jB9.setForeground(Color.GREEN);
            
        }
        else{
            
            jB9.setForeground(Color.BLUE);
            
        }
      choose_a_player1();
       winningGame2();
    }//GEN-LAST:event_jB9ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TicTakToe_s2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TicTakToe_s2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TicTakToe_s2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TicTakToe_s2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TicTakToe_s2().setVisible(true);
            }
        });
    try  
        {  
            sckt = new Socket("localhost",2222);  
            dtinpt = new DataInputStream(sckt.getInputStream());  
            dtotpt = new DataOutputStream(sckt.getOutputStream());  
            String msgin = "";  
            while(!msgin.equals("Exit"))  
            {  
                msgin=dtinpt.readUTF();  
                jB1.setText(jB1.getText().trim()+msgin);  
            }  
        }  
        catch(Exception e)  
        {  
  
        }  
        
        
    }
    
    
    
    
        
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton jB1;
    public javax.swing.JButton jB2;
    public javax.swing.JButton jB3;
    public javax.swing.JButton jB4;
    public javax.swing.JButton jB5;
    public javax.swing.JButton jB6;
    public javax.swing.JButton jB7;
    public javax.swing.JButton jB8;
    public javax.swing.JButton jB9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton jbtnExit2;
    private javax.swing.JButton jbtnReset2;
    private javax.swing.JLabel jlblPlayerO2;
    private javax.swing.JLabel jlblPlayerX2;
    // End of variables declaration//GEN-END:variables
}
