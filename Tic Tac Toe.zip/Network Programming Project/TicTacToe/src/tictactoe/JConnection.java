/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class JConnection {
   /* public static Connection connectdb(){
        Connection con=null;
        try {
            con=(Connection) (JConnection) DriverManager.getConnection("jdbc:derby://localhost:1527/MyDatabase","Prottoy ","1234");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(JConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
*/
    
    
    
}
