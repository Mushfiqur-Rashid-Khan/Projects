/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

/**
 *
 * @author HP
 */
class User {
    
    private int ID;
    private String Name,Address,Mobile, Category;
    
    public User(int ID, String Name,String Address,String Mobile,String Category){
        
        this.ID=ID;
        this.Name=Name;
        this.Address=Address;
        this.Mobile=Mobile;
        this.Category=Category;
       
        
    }
    
    public int getNo(){
        return ID;
    }
    
    public String getName(){
        return Name;
    }
    
    public String getAddress(){
        return Address;
    }
    
    public String getMobile(){
        return Mobile;
    }
    
     public String getCategory(){
        return Category;
    }
     
     

   
    
}
