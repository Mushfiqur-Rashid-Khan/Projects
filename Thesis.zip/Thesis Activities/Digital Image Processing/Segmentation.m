clear all;
close all;
I = imread('6.png');
BW = im2bw(I, 0.9);
BW = ~BW;
stats = regionprops(BW);
for index=1:length(stats)
if stats(index).Area > 200 && stats(index).BoundingBox(3)*stats(index).BoundingBox(4) < 30000
      x = ceil(stats(index).BoundingBox(1))
      y= ceil(stats(index).BoundingBox(2))
      widthX = floor(stats(index).BoundingBox(3)-1)
      widthY = floor(stats(index).BoundingBox(4)-1)
      subimage(index) = {BW(y:y+widthY,x:x+widthX,:)}; 
      figure, imshow(subimage{index})
      end
  end