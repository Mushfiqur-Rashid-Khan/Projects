I=imread('42.png');
I2 = im2double(I);
s=skewness(I2(:))

