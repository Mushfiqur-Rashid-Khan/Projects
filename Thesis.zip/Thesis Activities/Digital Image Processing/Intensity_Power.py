import cv2
import numpy as np

img_1=cv2.imread('101.png',0)

gamma=3.13
img_2=np.power(img_1,gamma)

"""gamma=3
img_3=np.power(img_1,gamma)

gamma=4
img_4=np.power(img_1,gamma)

cv2.imshow('input', img_1)
cv2.imshow('input', img_2)
cv2.imshow('input', img_3)"""
cv2.imshow('input', img_2)


