function I=thresholding(I3,thresh)
I=zeros(size(13));
for i=1:size(I3,1)
    for j=1:size(I3,2)
        if(I3(i,j)>thresh)
            I(i,j)=1;
        end
    end
end
end
