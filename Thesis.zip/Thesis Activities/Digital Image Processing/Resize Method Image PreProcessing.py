import matplotlib.pyplot as plt
import cv2

image = cv2.imread('1.png')
type(image)
image.shape
WIDTH = 300
HEIGHT = 300


image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

"""Scaling of Image"""
aspect = image.shape[1] / float(image.shape[0])
print(aspect)

if(aspect > 1):
    """ landscape orientation : wide image"""
    res = int(aspect * HEIGHT)
    scaled = cv2.resize(image, (res, HEIGHT))
if(aspect < 1):
    """portrait orientation : tall image"""
    res = int(WIDTH / aspect)
    scaled = cv2.resize(image, (WIDTH, res))
if(aspect == 1):
    scaled = cv2.resize(image, (WIDTH, HEIGHT))
plt.imshow(scaled)

"""Resizing of Image"""

resized = cv2.resize(image, (WIDTH, HEIGHT))
plt.imshow(resized)


