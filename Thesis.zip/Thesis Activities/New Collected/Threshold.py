import cv2
import numpy as np

img = cv2.imread('27.png')
retval, threshold = cv2.threshold(img, 115, 255, cv2.THRESH_BINARY)
cv2.imshow('original',img)
cv2.imshow('threshold',threshold)
cv2.waitKey(0)
cv2.destroyAllWindows()
