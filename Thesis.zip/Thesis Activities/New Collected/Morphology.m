im=imread('1.png');
se=strel('diamond',2);

ero=imerode(im,se);
dil=imdilate(im,se);


figure(3)
subplot(2,2,1)
imshow(ero)

subplot(2,2,2)
imshow(dil)





