M=fitcknn(X,'Var5');
crossmodel=crossval(M);
crossmodel