# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 03:07:43 2018

@author: HP
"""

""" Import Library """
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

""" Read CSV File """
df=pd.read_csv("Training_Update.csv")
X=df.iloc[:,0:5].values
y=df.iloc[:,1:5].values


from sklearn.datasets import load_iris

iris=load_iris()
print(iris)


iris.feature_names
print(iris.DESCR)

from sklearn.utils import shuffle
X=iris.data
Y=iris.target
x,y=shuffle(X,Y,random_state=0)

print(x)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=42)
x_train.shape

from sklearn.linear_model import LogisticRegression
lr=LogisticRegression()
lr.fit(x_train,y_train)

from sklearn.metrics import accuracy_score 
y_pred=lr.predict(x_test)
acc=accuracy_score(y_test,y_pred)
print(acc)



