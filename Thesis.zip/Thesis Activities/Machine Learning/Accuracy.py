# -*- coding: utf-8 -*-
"""
Created on Tue Dec 25 22:38:49 2018

@author: HP
"""


import pandas as pd


from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

lr=LogisticRegression()
svc=LinearSVC(C=1.0)
rfc=RandomForestClassifier(n_estimators=100)

df=pd.read_csv("Training.csv")

from sklearn.model_selection import train_test_split

train,test= train_test_split(df,test_size=0.3)

train_feat=train.iloc[:,:7]
train_targ=train["visible"]


print("{0:0.2f}% in training set".format((len(train_feat)/len(df.index)) * 100))
print("{0:0.2f}% in testing set".format((1-len(train_feat)/len(df.index)) * 100))


lr.fit(train_feat,train_targ)

lr.score(train_feat,train_targ)

acc=lr.score(train_feat,train_targ)
acc1=acc*100
print(acc1,'%')




