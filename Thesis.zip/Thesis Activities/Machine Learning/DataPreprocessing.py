# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
""" Import Library """
import numpy as np
import pandas as pd

""" Read CSV File """
df=pd.read_csv("Training_Update.csv")
X=df.iloc[:,0:7].values
y=df.iloc[:,:8].values

""" Data Spliting: Training and Testing """
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

# Load dataset.
iris = load_iris()
X, y = iris.data, iris.target



# split data into training and test data.
train_X, test_X, train_y, test_y = train_test_split(X, y, 
                                                    train_size=0.7,
                                                    test_size=0.3,
                                                    random_state=123)
print("Labels for training and testing data")
print(train_y)
print(test_y)

print("{0:0.2f}% in training set".format((len(train_X)/len(df.index)) * 100))
print("{0:0.2f}% in training set".format((len(test_X)/len(df.index)) * 100))


"""Cross Validation"""
from sklearn.model_selection import cross_val_score
# 10-fold cross-validation with K=5 for KNN (the n_neighbors parameter)
# k = 5 for KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=5)

# Use cross_val_score function
# We are passing the entirety of X and y, not X_train or y_train, it takes care of splitting the dat
# cv=10 for 10 folds
# scoring='accuracy' for evaluation metric - althought they are many
scores = cross_val_score(knn, X, y, cv=10, scoring='accuracy')
print(scores)


k_range = range(1, 101)
# empty list to store scores
k_scores = []

# 1. we will loop through reasonable values of k
for k in k_range:
    # 2. run KNeighborsClassifier with k neighbours
    knn = KNeighborsClassifier(n_neighbors=k)
    # 3. obtain cross_val_score for KNeighborsClassifier with k neighbours
    scores = cross_val_score(knn, X, y, cv=10, scoring='accuracy')
    # 4. append mean of scores for k neighbors to k_scores list
    k_scores.append(scores.mean())


print(k_scores)

print('Length of list', len(k_scores))
print('Max of list', max(k_scores))

"""Graph"""
import matplotlib.pyplot as plt


# plot the value of K for KNN (x-axis) versus the cross-validated accuracy (y-axis)
# plt.plot(x_axis, y_axis)
plt.plot(k_range, k_scores)
plt.xlabel('Value of K for KNN')
plt.ylabel('Cross-validated accuracy')











               
               
