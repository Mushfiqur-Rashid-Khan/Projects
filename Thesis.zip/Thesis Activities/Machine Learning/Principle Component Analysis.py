# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 23:35:22 2019

@author: HP
"""

import os
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
import seaborn as sns


from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

df = pd.read_csv('Template_Matching.csv')


X = df.drop(['image'], axis=1)
#X = X.values
y = df['visible']
X_t = df.drop(['image'], axis=1)



from sklearn.preprocessing import StandardScaler
X_std = StandardScaler().fit_transform(X)
X_t_std = StandardScaler().fit_transform(X_t)

cov_matrix = np.cov(X_std.T)
print('Covariance Matrix : %s' % cov_matrix)

e_vals, e_vecs = np.linalg.eig(cov_matrix)
print('EigenValues : %s' % e_vals)

for ev in e_vecs:
    np.testing.assert_array_almost_equal(1.0, np.linalg.norm(ev))
print('Everything ok!')



e_pairs = [(np.abs(e_vals[i]), e_vecs[:,i]) for i in range(len(e_vals))]

# Sort the (eigenvalue, eigenvector) tuples from high to low
e_pairs.sort(key=lambda x: x[0], reverse=True)

# Visually confirm that the list is correctly sorted by decreasing eigenvalues
print('Eigenvalues in descending order:')
for i in e_pairs:
    print(i[0])
    
projection_matrix = np.hstack((e_pairs[0][1].reshape(11,1),
                             e_pairs[1][1].reshape(11,1),
                             e_pairs[2][1].reshape(11,1),
                             e_pairs[3][1].reshape(11,1),
                             e_pairs[4][1].reshape(11,1),
                             e_pairs[5][1].reshape(11,1)))
print(projection_matrix)

X_proj = X_std.dot(projection_matrix)

plt.figure(figsize = (5,4))
plt.scatter(X_proj[:,0],X_proj[:,1], c='goldenrod',alpha=0.5)
plt.ylim(-10,10)
plt.show()


kmeans = KMeans(n_clusters=2)
# Compute cluster centers and predict cluster indices
X_clustered = kmeans.fit_predict(X_proj)

# Define our own color map
LABEL_COLOR_MAP = {0 : 'r',1 : 'b',2 : 'y'}
label_color = [LABEL_COLOR_MAP[l] for l in X_clustered]

# Plot the scatter digram
plt.figure(figsize = (7,7))
plt.scatter(X_proj[:,0],X_proj[:,1], c= label_color, alpha=0.5) 
plt.show()

df = pd.DataFrame(X_proj)
df['X_clustered']= X_clustered
sns.pairplot(df, hue='X_clustered', palette= 'Dark2', diag_kind='kde',size=1.85)
df.drop(['X_clustered'], axis=1)
df['label']=y
sns.pairplot(df, hue='label', palette= 'Dark2', diag_kind='kde')


ntrain = X_proj.shape[0]
SEED = 0 

class SklearnHelper(object):
    def __init__(self, clf, seed=0, params=None):
        params['random_state'] = seed
        self.clf = clf(**params)

    def train(self, x_train, y_train):
        self.clf.fit(x_train, y_train)

    def predict(self, x):
        return self.clf.predict(x)
    
    def fit(self,x,y):
        return self.clf.fit(x,y)
    
    def feature_importances(self,x,y):
        print(self.clf.fit(x,y).feature_importances_)
        

from sklearn.model_selection import RandomizedSearchCV
def hypertuning_rscv(est, p_distr, nbr_iter,X,y):
    rdmsearch = RandomizedSearchCV(est, param_distributions=p_distr,
                                  n_jobs=-1, n_iter=nbr_iter, cv=9)
    #CV = Cross-Validation ( here using Stratified KFold CV)
    start = time()
    rdmsearch.fit(X,y)
    print('hyper-tuning time : %d seconds' %  (time()-start))
    start = 0
    ht_params = rdmsearch.best_params_
    ht_score = rdmsearch.best_score_
    return ht_params, ht_score

est = SVC()
from time import time
from scipy.stats import norm
svc_p_dist={'kernel':['linear','poly','rbf'],
            'C':norm(loc=0.5, scale=0.15)}
svc_parameters, svc_ht_score = hypertuning_rscv(est, svc_p_dist, 200, X_proj, y)
print(svc_parameters)
print('Hyper-tuned model score :')
print(svc_ht_score*100)



svc = SklearnHelper(clf=SVC, seed=SEED, params=svc_parameters)
svc.train(X_proj,y)
svc.fit(X_proj,y)
pred = svc.predict(X_proj)
print(accuracy_score(pred, y)*100)



company=['letter','digit1','digit2','digit3','digit4','digit5','digit6','city','metro','hyp1','hyp2']

ypos=np.arange(len(company))

tot = sum(e_vals)
var_exp = [(i / tot)*100 for i in sorted(e_vals, reverse=True)]
cum_var_exp = np.cumsum(var_exp)

with plt.style.context('seaborn-whitegrid'):
    plt.figure(figsize=(6, 8))

    plt.bar(range(11), var_exp, alpha=0.5, align='center',label='individual explained variance')
    plt.step(range(11), cum_var_exp, where='mid',label='cumulative explained variance')
    plt.xticks(ypos,company)
    plt.ylabel('Explained Variance Ratio(%)')
    plt.xlabel('Principal Components')
    plt.legend(loc='best')
    plt.tight_layout()

