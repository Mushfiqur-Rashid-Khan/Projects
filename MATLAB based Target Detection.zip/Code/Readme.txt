This file is about the working procedure of the whole project.
First of all, We have collected dataset by using various pictures from the internet such as cars,?owers,bo?les etc.We have used single object images and also multiple object images
to see how well our counting function works inside the project.And we
also have various objects from our very own data-set for our project.
?en,a?er completing prepossessing of our images,we have been
able to get sub-images of our targeted objects and count the total number
of them inside the main image.

After collecting the dataset, we made the Graphical User Interface which is called GUI. For our GUI design,we have used a single frame image-box,the imagebox
contains a bu?on.By clicking the bu?on,the bu?on will give us the
desired sub-image of the item example:cars,?owers,water bo?les etc.
But First,we must remember the fact that di?erent objects comes
with di?erent sizes and covering di?erent parts of the image.And also,the
target in the image can be very small and also be very big.So,our algorithm
is pitched in ?nding various size objects.But for di?erent sized
objects we must have to change the parts of our algorithm to achieve
our desired goal.

We have studied 1 published paper, which is related to our project.
OpenCV (Open source computer vision) is a library of programming
functions mainly aimed at real-time computer vision. Originally developed
by Intel, it was later supported by Willow Garage then Itseez
(which was later acquired by Intel). ?e library is cross-platform and
free for use under the open-source BSD license. OpenCV (Open Source
Computer Vision Library) is an open source computer vision and machine
learning so?ware library. OpenCV was built to provide a common
infrastructure for computer vision applications and to accelerate
the use of machine perception in the commercial products. Being a
BSD-licensed product, OpenCV makes it easy for businesses to utilize
and modify the code.


We would use the numpy property of python and import �cv2� inside
the project and then start our desired work.
Next we would create two images of our targeted image.One of RGB
properties and one of �img2gray� properties.
?en,we would create a template with width=w and height=h properties
and later search the targeted image to detect the object we desire
to ?nd.
?en,By using the OpenCV object called �cv2.matchtemplate� we
would compare both those images and also to be noted that,we have a
threshold value because If pixel value is greater than a threshold value,
it is assigned one value (may be white), else it is assigned another value
(may be black). ?e function used is cv.threshold. OpenCV provides
di?erent styles of thresholding and it is decided by the fourth parameter
of the function.?us,we will check the places where our created
variable �res� (result) is greater than the threshold values by using the
following line:
loc = np.where( res = threshold)
cv2.rectangle(img rgb, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)
cv2.imshow(�Detected�,img rgb)
?e upper code would ?rst describe about cv2.rectangle.
Cv2.rectangle tells us about the ability to add di?erent geometric shapes
just like lines, circles and rectangle etc. � cv2.line() ?is function is
used to draw line on an image. cv2.rectangle() ?is function is used to
draw rectangle on an image.
